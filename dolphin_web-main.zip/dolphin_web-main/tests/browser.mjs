import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { readFile, writeFile, mkdtemp, rm } from 'node:fs/promises';
import { join, resolve, extname, sep } from 'node:path';
import { tmpdir } from 'node:os';
import puppeteer from 'puppeteer-core';
const root = resolve('web');
let discBytes;
let imageRequests = 0;
let metadataRequests = 0;
const server = createServer(async (request, response) => {
  try {
    const url = new URL(request.url, 'http://localhost');
    if (!url.pathname.startsWith('/dolphin_web/')) { response.writeHead(404).end(); return; }
    if (url.pathname === '/dolphin_web/conditional-script.js') {
      if (request.headers['if-none-match'] || request.headers['if-modified-since']) {
        response.writeHead(304).end();
      } else {
        response.writeHead(200, {'content-type':'text/javascript',etag:'"bootstrap-v1"'});
        response.end('globalThis.__conditionalBootstrap = true;');
      }
      return;
    }
    if (url.pathname === '/dolphin_web/test-download') {
      imageRequests++;
      response.writeHead(200, {'content-type':'application/octet-stream','access-control-allow-origin':'*','content-length':discBytes.length});
      if (url.searchParams.get('name') === 'Cancelled (USA).iso') {
        response.write(discBytes.subarray(0, 128));
        const timer = setInterval(() => response.write(discBytes.subarray(0, 128)), 500);
        response.on('close', () => clearInterval(timer));
      } else response.end(discBytes);
      return;
    }
    const file = resolve(root, decodeURIComponent(url.pathname.slice('/dolphin_web/'.length)) || 'index.html');
    if (!file.startsWith(root + sep)) { response.writeHead(403).end(); return; }
    const types = {'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.css':'text/css','.wasm':'application/wasm','.json':'application/json'};
    // Intentionally omit isolation headers to exercise the GitHub Pages worker.
    const body = await readFile(file);
    response.writeHead(200, {'content-type':types[extname(file)] || 'application/octet-stream'});
    response.end(body);
  } catch { response.writeHead(404).end(); }
});
await new Promise(done => server.listen(0, '127.0.0.1', done));
const temp = await mkdtemp(join(tmpdir(), 'dolphin-browser-'));
let browser;
try {
  browser = await puppeteer.launch({executablePath:process.env.CHROME_PATH || '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', headless:true, args:['--enable-unsafe-webgpu', ...(process.env.CI ? ['--no-sandbox'] : [])]});
  const page = await browser.newPage();
  const errors = [];
  await page.setRequestInterception(true);
  page.on('request', request => {
    if (request.url() === 'https://archive.org/metadata/Wii_ISO') {
      metadataRequests++;
      return request.respond({status:200,headers:{'access-control-allow-origin':'*','content-type':'application/json'},body:JSON.stringify({files:[
        {name:'Remote test (USA).iso',size:0x3000},
        {name:'Cancelled (USA).iso',size:0x3000},
        {name:'Broken (USA).iso',size:0x3001},
      ]})});
    }
    if (request.url().startsWith('https://archive.org/cors/Wii_ISO/')) {
      return request.respond({status:302,headers:{'access-control-allow-origin':'*',location:`http://127.0.0.1:${server.address().port}/dolphin_web/test-download?name=${encodeURIComponent(decodeURIComponent(new URL(request.url()).pathname.split('/').pop()))}`}});
    }
    void request.continue();
  });
  page.on('pageerror', error => { errors.push(error.message); console.log('PAGE ERROR',error.message); });
  page.on('console', message => { if(message.type() === 'error') console.log('CONSOLE',message.text()); });
  await page.goto(`http://127.0.0.1:${server.address().port}/dolphin_web/`);
  await page.waitForFunction(() => crossOriginIsolated && window.__host && document.querySelector('.library-section')?.dataset.ready === 'true', {timeout:60000});
  assert.equal(await page.evaluate(() => window.__host.coreKind), 'upstream');
  const preferenceIds = ['settingSpeed','settingPresenter','settingWasmJit','settingAutoProfile','nunchukConnected','displayUpscaling','aspectSelect','volumeDial','mouseMode','controllerSelect','controllerDeadzone','touchMode','touchSize','touchOpacity','librarySource','librarySearch','libraryRegion','librarySort','libraryPageSize'];
  const preferences = () => page.evaluate(ids => Object.fromEntries(ids.map(id => {
    const control=document.getElementById(id);
    return [id,control.type==='checkbox'?control.checked:control.value];
  })), preferenceIds);
  const defaultPreferences=await preferences();
  await page.waitForFunction(()=>window.DolphinLayout);
  const defaultLayout=await page.evaluate(()=>window.DolphinLayout.getState());
  // Display scaling uses composition; selecting it must preserve the existing
  // frame dimensions, core settings and default filtering across a reload.
  const displayBefore = await page.$eval('#screen', el => ({width:el.width,height:el.height,filter:getComputedStyle(el).imageRendering}));
  assert.equal(await page.$eval('#displayUpscaling',el=>el.value),'smooth');
  const originalUrl = page.url();
  await page.select('#displayUpscaling','smooth');
  assert.deepEqual(await page.$eval('#screen',el=>({width:el.width,height:el.height,filter:getComputedStyle(el).imageRendering})),{...displayBefore,filter:'auto'});
  assert.equal(page.url(),originalUrl,'display scaling must not restart emulation');
  assert.equal(await page.evaluate(()=>localStorage.getItem('dolphin-display-upscaling')),'smooth');
  await page.select('#displayUpscaling','crisp');
  assert.equal(await page.$eval('#screen',el=>getComputedStyle(el).imageRendering),'pixelated');
  await page.select('#displayUpscaling','smooth');
  assert.equal(await page.$eval('#screen',el=>getComputedStyle(el).imageRendering),displayBefore.filter);
  const conditionalScript = await page.evaluate(async () => {
    const response = await fetch('./conditional-script.js', {
      headers: {'If-None-Match':'"bootstrap-v1"', 'If-Modified-Since':'Thu, 08 Oct 2026 00:00:00 GMT'}
    });
    return {status:response.status, body:await response.text()};
  });
  assert.equal(conditionalScript.status, 200, 'isolation worker must retrieve a full response on reload');
  assert.equal(conditionalScript.body, 'globalThis.__conditionalBootstrap = true;');
  // Azahar widget controls persist and can restore hidden cards.
  await page.waitForFunction(()=>window.DolphinLayout);
  await page.click('[data-widget="game"] .widget-tool-collapse');
  assert.equal(await page.$eval('[data-widget="game"]',el=>el.classList.contains('is-collapsed')),true);
  await page.click('#btn-layout-menu');
  await page.click('#btn-layout-reset');
  assert.equal(await page.$eval('[data-widget="game"]',el=>el.classList.contains('is-collapsed')),false);
  await page.click('#btn-layout-menu-close');
  // Exercise actual DOM events and capture the state sent to the emulator host.
  await page.evaluate(() => {
    const original = window.__host.setInputState.bind(window.__host);
    window.__host.setInputState = state => { window.__lastInput = state; original(state); };
  });
  await page.keyboard.down('x');
  assert.equal(await page.evaluate(() => window.__lastInput.mask & 1), 1);
  await page.keyboard.up('x');
  await page.waitForFunction(() => (window.__lastInput.mask & 1) === 0);
  assert.equal(await page.evaluate(() => window.__lastInput.mask & 1), 0);
  await page.focus('#librarySearch');
  await page.keyboard.type('x');
  assert.equal(await page.evaluate(() => window.__lastInput.mask & 1), 0, 'typing must not press A');
  await page.$eval('#librarySearch', el => { el.value = ''; el.dispatchEvent(new Event('input')); el.blur(); });
  await page.$eval('.input-settings', el => el.open = true);
  await page.locator('[data-binding="A"]').click();
  await page.keyboard.press('u');
  await page.evaluate(() => document.activeElement.blur());
  await page.keyboard.down('u');
  assert.equal(await page.evaluate(() => window.__lastInput.mask & 1), 1);
  await page.evaluate(() => window.dispatchEvent(new Event('blur')));
  assert.equal(await page.evaluate(() => window.__lastInput.mask), 0, 'blur releases held controls');
  await page.keyboard.up('u');
  await page.select('#mouseMode', 'stick');
  const inputCanvas = await page.$('#screen');
  await inputCanvas.scrollIntoView();
  const rect = await inputCanvas.boundingBox();
  await page.mouse.move(rect.x + rect.width * .9, rect.y + rect.height * .2);
  await page.mouse.down();
  assert.equal(await page.evaluate(() => window.__lastInput.mask & 1), 1);
  assert.ok(await page.evaluate(() => window.__lastInput.stickX > 180));
  await page.mouse.up();
  assert.equal(await page.evaluate(() => window.__lastInput.stickX), 128);
  await page.select('#mouseMode','cstick');
  await inputCanvas.scrollIntoView();
  const aimRect = await inputCanvas.boundingBox();
  await page.mouse.move(aimRect.x+aimRect.width*.75,aimRect.y+aimRect.height*.25);
  assert.ok(await page.evaluate(()=>window.__lastInput.cStickX>160&&window.__lastInput.cStickY>160),'hover must aim without a held mouse button');
  await page.mouse.click(aimRect.x+aimRect.width*.75,aimRect.y+aimRect.height*.25);
  await page.waitForFunction(()=>(window.__lastInput.mask&1)===0);
  assert.ok(await page.evaluate(()=>window.__lastInput.cStickX>160&&window.__lastInput.cStickY>160),'mouse-up must keep absolute aim');
  await page.select('#mouseMode','off');
  await page.evaluate(() => {
    window.__padPollCount=0;window.__testPads=[];
    Object.defineProperty(navigator,'getGamepads',{configurable:true,value:()=>{window.__padPollCount++;return window.__testPads;}});
  });
  await new Promise(resolve=>setTimeout(resolve,550));
  const idlePolls=await page.evaluate(()=>window.__padPollCount);
  assert(idlePolls>=2&&idlePolls<=8,`idle gamepad polling should be bounded, got ${idlePolls}`);
  await page.evaluate(() => {
    window.__testPads = [{index:0,id:'Test Bluetooth controller',connected:true,mapping:'standard',axes:[.8,0,0,0],buttons:Array.from({length:17},(_,i)=>({pressed:i===0,value:i===0?1:0}))}];
    window.__padPollCount=0;window.dispatchEvent(new Event('gamepadconnected'));
  });
  await page.waitForFunction(() => window.__lastInput?.mask & 1);
  assert.ok(await page.evaluate(() => window.__lastInput.stickX > 180));
  assert.match(await page.$eval('#controllerStatus', el => el.textContent), /Test Bluetooth/);
  await new Promise(resolve=>setTimeout(resolve,150));
  const activePolls=await page.evaluate(()=>window.__padPollCount);
  assert(activePolls>8&&activePolls<35,`connected controller polling should remain responsive and bounded, got ${activePolls}`);
  await page.select('#controllerSelect','off');
  await page.waitForFunction(() => window.__lastInput?.mask === 0 && window.__lastInput.stickX === 128);
  await page.select('#controllerSelect','auto');
  await page.evaluate(() => window.__testPads = []);
  await page.waitForFunction(() => document.querySelector('#controllerStatus').textContent.includes('Pair'));
  await page.select('#displayUpscaling','smooth');
  await page.goto(`http://127.0.0.1:${server.address().port}/dolphin_web/?inputPersistence=1`, {waitUntil:"networkidle0"});
  await page.waitForFunction(() => window.__host && document.querySelector('.library-section')?.dataset.ready === 'true', {timeout:60000});
  assert.equal(await page.$eval('#displayUpscaling',el=>el.value),'smooth');
  await page.select('#displayUpscaling','smooth');
  assert.match(await page.$eval('[data-binding="A"]', el => el.textContent), /KeyU/);
  await page.$eval('#resetBindings', el => el.click());
  await page.select('#librarySource','local');
  // Generated metadata-only disc: validates DiscIO, not commercial gameplay.
  const bytes = Buffer.alloc(0x3000);
  bytes.write('TSTE01', 0); bytes.writeUInt32BE(0xc2339f3d, 0x1c); bytes.write('Dolphin test image', 0x20);
  const fields = {0x420:0x1000,0x424:0x2800,0x428:0x24,0x458:1,0x1000:0x100,0x1048:0x80003100,0x1090:0x40,0x10d8:0x80400000,0x10dc:0x1000,0x10e0:0x80003100,0x2454:0x20,0x2458:0x10,0x2800:0x01000000,0x2808:2,0x2810:0x2900,0x2814:4};
  for (const [offset,value] of Object.entries(fields)) bytes.writeUInt32BE(value, Number(offset));
  bytes.write('2026/10/08',0x2440); bytes.write('opening.bnr',0x2818); bytes.write('BNR1',0x2900);
  discBytes = bytes;
  const image = join(temp, 'Dolphin test.iso'); await writeFile(image, bytes);
  await page.evaluate(()=>{ window.__originalCreateWritable=FileSystemFileHandle.prototype.createWritable; FileSystemFileHandle.prototype.createWritable=undefined; });
  await (await page.$('#libraryFiles')).uploadFile(image);
  await page.waitForFunction(() => document.querySelector('#libraryCount').textContent === '(1)').catch(async error=>{console.log(await page.$eval('#libraryStatus',el=>el.textContent));throw error;});
  await page.evaluate(()=>{ FileSystemFileHandle.prototype.createWritable=window.__originalCreateWritable; });
  await page.goto(`http://127.0.0.1:${server.address().port}/dolphin_web/?visit=2`, {waitUntil:'networkidle0'});
  await page.waitForFunction(() => document.querySelector('.library-section')?.dataset.ready === 'true');
  await page.select('#librarySource','local');
  await page.waitForFunction(() => document.querySelector('#libraryCount')?.textContent === '(1)');
  await page.type('#librarySearch','no-match');
  assert.equal(await page.$eval('#libraryRows', node => node.textContent), 'No matching games.');
  await page.$eval('#librarySearch',node=>{node.value='';node.dispatchEvent(new Event('input'));});
  await page.locator('#libraryRows button').click();
  await page.waitForFunction(() => window.__host?.game?.gameId === 'TSTE01', {timeout:60000});
  assert.equal(await page.evaluate(() => window.__host.mode), 'dolphin');
  assert.equal(await page.evaluate(() => window.__host.game.bootDolOffset), 0x1000);
  // Library actions stay disabled until the mount settles; CI runners can take well over 30s.
  await page.waitForFunction(() => document.querySelector('#libraryRows button:last-child')?.disabled === false, {timeout:120000});
  await page.locator('#libraryRows button:last-child').click();
  await page.waitForFunction(() => document.querySelector('#libraryCount').textContent === '(0)');
  await page.goto(`http://127.0.0.1:${server.address().port}/dolphin_web/?visit=3`);
  await page.waitForFunction(() => document.querySelector('.library-section')?.dataset.ready === 'true');
  await page.select('#librarySource','local');
  await page.waitForFunction(() => document.querySelector('#libraryCount')?.textContent === '(0)');

  // Run download cancellation and truncation cleanup through Safari's
  // worker writer path as well as the normal native-writer unit tests.
  await page.evaluate(()=>{ FileSystemFileHandle.prototype.createWritable=undefined; });
  // Archive catalog, download cancellation, truncation cleanup and cached replay.
  await page.waitForFunction(() => document.querySelector('.library-section')?.dataset.catalogLoaded === 'true');
  await page.select('#librarySource','archive');
  await page.waitForFunction(() => document.querySelector('#libraryCount').textContent === '(3)');
  assert.equal(await page.$eval('#librarySourceLink', node => node.href), 'https://archive.org/download/Wii_ISO');
  const remoteRow = '#libraryRows tr[data-name="Remote test (USA).iso"]';
  const cancelRow = '#libraryRows tr[data-name="Cancelled (USA).iso"]';
  const brokenRow = '#libraryRows tr[data-name="Broken (USA).iso"]';
  await page.locator(`${cancelRow} button:last-child`).click();
  await page.waitForFunction(() => !document.querySelector('#libraryDownload').hidden && document.querySelector('#libraryProgress').value > 0);
  await page.locator('#libraryCancel').click();
  await page.waitForFunction(() => document.querySelector('#libraryStatus').textContent.includes('Download cancelled'));
  assert.equal(await page.$eval('#libraryReadyCount', node => node.textContent), '(0)');
  await page.locator(`${brokenRow} button:last-child`).click();
  await page.waitForFunction(() => document.querySelector('#libraryStatus').textContent.includes('incomplete'));
  assert.equal(await page.$eval('#libraryReadyCount', node => node.textContent), '(0)');
  await page.locator(`${remoteRow} button:last-child`).click();
  await page.waitForFunction(() => document.querySelector('#libraryReadyCount').textContent === '(1)');
  assert.equal(imageRequests,3);
  assert((await page.$eval(`${remoteRow} a`, node => node.href)).startsWith('https://archive.org/download/Wii_ISO/'));
  const save = await page.evaluate(async () => {
    const directory = await (await navigator.storage.getDirectory()).getDirectoryHandle('dolphin-library-v1');
    const entries=[];for await(const [key] of directory.entries()) entries.push(key);return entries;
  });
  assert.equal(save.length,2,'only the complete disc and metadata should remain');
  const session = await page.createCDPSession();
  await session.send('Browser.setDownloadBehavior',{behavior:'allow',downloadPath:temp});
  await page.locator('#libraryReadyList button:nth-child(2)').click();
  const saveDeadline = Date.now() + 5000;
  let savedFile;
  while (Date.now() < saveDeadline) {
    try { savedFile = await readFile(join(temp, 'Remote test (USA).iso')); if (savedFile.length === bytes.length) break; } catch {}
    await new Promise(resolve => setTimeout(resolve, 50));
  }
  assert.deepEqual(savedFile, bytes, 'Save file must download the cached image to the device');
  await page.goto(`http://127.0.0.1:${server.address().port}/dolphin_web/?visit=4`);
  await page.waitForFunction(() => document.querySelector('#libraryReadyCount')?.textContent === '(1)');
  await page.setOfflineMode(true);
  await page.locator('#libraryReadyList button').click();
  await page.waitForFunction(() => document.querySelector('#libraryStatus').textContent.includes('from the local cache'), {timeout:60000});
  assert.equal(await page.evaluate(() => window.__host.game.gameId),'TSTE01');
  assert.equal(imageRequests,3,'cached Play must not fetch the disc again');
  await page.$eval('#libraryReadyList button:last-child', button => button.click());
  await page.waitForFunction(() => document.querySelector('#libraryReadyCount').textContent === '(0)');
  await page.setOfflineMode(false);
  await page.waitForFunction(() => document.querySelector('.library-section')?.dataset.catalogLoaded === 'true');
  await page.locator(`${remoteRow} button`).click();
  await page.waitForFunction(() => document.querySelector('#libraryStatus').textContent.includes('from the local cache') && document.querySelector('#libraryReadyCount').textContent === '(1)', {timeout:60000});
  assert.equal(imageRequests,4,'Play on an uncached archive row must download, cache and mount it');

  // All preferences restore on a new visit before constructing the core.
  for (const [id,value] of [['settingSpeed','0.75'],['settingPresenter','2d'],['displayUpscaling','smooth'],['aspectSelect','16:9'],['mouseMode','off'],['controllerSelect','off'],['touchMode','on'],['librarySource','local'],['libraryRegion','USA'],['librarySort','size'],['libraryPageSize','50']]) await page.select(`#${id}`,value);
  for (const id of ['settingWasmJit','settingAutoProfile','nunchukConnected']) await page.$eval(`#${id}`,control=>control.click());
  for (const [id,value] of [['volumeDial','37'],['controllerDeadzone','0.32'],['touchSize','125'],['touchOpacity','65'],['librarySearch','Remote']]) await page.$eval(`#${id}`,(control,value)=>{control.value=value;control.dispatchEvent(new Event('input',{bubbles:true}));},value);
  await page.click('#overlayToggle');
  await page.$eval('[data-widget="game"] .widget-tool-collapse',button=>button.click());
  await page.$eval('[data-widget="savestates"] .widget-tool-hide',button=>button.click());
  await page.click('#btn-layout-menu');
  for (const [id,value] of [['layout-widget-width','360'],['layout-gap','20']]) await page.$eval(`#${id}`,(control,value)=>{control.value=value;control.dispatchEvent(new Event('input'));},value);
  await page.click('#layout-beside-screen');
  await page.select('[data-widget-id="input"] select','2');
  await page.$eval('[data-widget-id="library"] button',button=>button.click());
  await page.click('#btn-layout-menu-close');
  const savedPreferences=await preferences();
  const savedLayout=await page.evaluate(()=>window.DolphinLayout.getState());
  await page.goto(`http://127.0.0.1:${server.address().port}/dolphin_web/?preferences=1`);
  await page.waitForFunction(()=>window.DolphinLayout && document.querySelector('.library-section')?.dataset.ready==='true',{timeout:60000});
  assert.deepEqual(await preferences(),savedPreferences,'all control values must restore on a new visit');
  assert.deepEqual(await page.evaluate(()=>window.DolphinLayout.getState()),savedLayout,'layout order, sizing, visibility and spacing must restore');
  assert.equal(await page.evaluate(()=>window.__host.presenterBackend),'2d');
  assert.equal(await page.evaluate(()=>window.__host.ppcWasmJit),false,'cached settings must configure the emulator, not only its controls');
  assert.equal(await page.$eval('#screenHud',node=>node.hidden),true);
  assert.equal(await page.evaluate(()=>window.__audio.volume),.37);

  // Settings-only reset keeps the layout; full reset also restores every card.
  await Promise.all([page.waitForNavigation(),page.$eval('#settingsResetButton',button=>button.click())]);
  await page.waitForFunction(()=>window.DolphinLayout && document.querySelector('.library-section')?.dataset.ready==='true',{timeout:60000});
  assert.deepEqual(await preferences(),defaultPreferences);
  assert.deepEqual(await page.evaluate(()=>window.DolphinLayout.getState()),savedLayout,'settings reset must keep layout');
  assert.equal(await page.evaluate(()=>window.__host.ppcWasmJit),true);
  assert.equal(await page.$eval('#libraryReadyCount',node=>node.textContent),'(1)','reset must keep cached game files');
  assert.equal(new URL(page.url()).search,'','reset must also remove URL overrides');
  await page.select('#mouseMode','off');
  await page.click('#btn-layout-menu');
  await Promise.all([page.waitForNavigation(),page.click('#resetAllButton')]);
  await page.waitForFunction(()=>window.DolphinLayout && document.querySelector('.library-section')?.dataset.ready==='true',{timeout:60000});
  assert.deepEqual(await preferences(),defaultPreferences);
  assert.deepEqual(await page.evaluate(()=>window.DolphinLayout.getState()),defaultLayout);
  assert.equal(await page.$eval('#libraryReadyCount',node=>node.textContent),'(1)');
  await page.$eval('#libraryReadyList button:last-child', button => button.click());
  await page.waitForFunction(() => document.querySelector('#libraryReadyCount').textContent === '(0)');
  assert(metadataRequests >= 1);
  assert.deepEqual(errors, []);
  console.log('PASS: Pages isolation, real Dolphin DiscIO, local library, archive catalog/downloads, cancellation, truncation cleanup, persistence and offline cached replay. Gameplay not exercised.');
} finally {
  await browser?.close();
  await new Promise(done => server.close(done));
  await rm(temp, {recursive:true, force:true});
}
